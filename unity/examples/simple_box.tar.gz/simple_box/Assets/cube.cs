﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

// The coordinates of the cube are read from a text file and
// the cube moves based on such coordinates.

public class cube : MonoBehaviour {

    // File where coordinates are stored
    string path = "Assets/sequence.txt";
    // String coordinates are saved in this list
    List<string> coords;
    // Iterator for the coordinates sequence
    int i = 0;

    void Awake()
    {
        // Don't Sync and reduce frame rate
        QualitySettings.vSyncCount = 0;
        // Increase this variable to modify the frame rate
        Application.targetFrameRate = 2;
    }

    // Use this for initialization
    void Start () {
        print ("Start code");
        coords = new List<string>();
        StreamReader reader = new StreamReader(path);
        string line;
        while((line = reader.ReadLine()) != null) {
            coords.Add(line);
        }
        reader.Close();
    }
	
	// Update is called once per frame
	void Update () {
        // Iterate through the coordinates
        int size = coords.Count;
        if (size > 0)
        {
            i++;
            if (i == size)
            {
                i = 0;
            }
            string[] subcoords = coords[i].Split(' ');
            float x = float.Parse(subcoords[0], CultureInfo.InvariantCulture);
            float y = float.Parse(subcoords[1], CultureInfo.InvariantCulture);
            float z = float.Parse(subcoords[2], CultureInfo.InvariantCulture);
            Vector3 vec = new Vector3(x, y, z);
            Debug.Log(vec);
            transform.position = vec;
        }
	}

    void OnApplicationQuit()
    {
        Debug.Log("Application ending after " + Time.time + " seconds");
    }
}
